
angular.module('ngCordova', [
  'ngCordova.plugins'
]);
